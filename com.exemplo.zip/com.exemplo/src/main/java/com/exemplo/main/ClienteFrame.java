package com.exemplo.main;


import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.exemplo.model.Cliente;
import com.exemplo.service.ClienteService;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.StringTokenizer;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.LayoutStyle.ComponentPlacement;

public class ClienteFrame extends JFrame {


	private static final long serialVersionUID = -7666904947797883899L;
	
	
	private JPanel contentPane;
	private JTextField nomeTextField;
	private JTextField enderecoTextField;
	private JTextField bairroTextField;
	private JTextField cidadeTextField;
	private JTextField telefoneTextField;
	private JTextField cepTextField;
	private JTextField numeroTextField;
	
	private JButton btnSalvar;

	private JButton btnExcluir;
	
	private JButton btnCancelar;
	private JTextField codigoTextField;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					for ( LookAndFeelInfo laf : UIManager.getInstalledLookAndFeels()) {
						if ("Mimbus".equals(laf.getName())){
							UIManager.setLookAndFeel(laf.getClassName());
						}
					}
					ClienteFrame frame = new ClienteFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public ClienteFrame() {
		
		initComponents();
		createEvents();
		
		
	}


	private void createEvents() {
		
		nomeTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					enderecoTextField.requestFocus();
				}
			}
		});
		nomeTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent f) {
				verificarDigitacao();
			}
		});
		enderecoTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					numeroTextField.requestFocus();
				}
			}
		});
		enderecoTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				verificarDigitacao();
			}
		});
		numeroTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
					bairroTextField.requestFocus();
				}
			}
		});
		numeroTextField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusLost(FocusEvent e) {
				verificarDigitacao();
			}
		});
		
		
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ClienteService clienteService = new ClienteService();
				Cliente cliente = pegarDadosClienteFromTela();
				if (cliente.getId() == null ) {
					clienteService.salvarCliente(cliente);
				} else {
					clienteService.alterarCLiente(cliente);
				}
			}
		});
		
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
				
			}
		});
		
	}
	
	protected Cliente pegarDadosClienteFromTela() {
		Cliente cliente = new Cliente();
		if ( (!codigoTextField.getText().isEmpty()) || !(codigoTextField.getText() == null) ) {
			cliente.setId(Long.valueOf(codigoTextField.getText()));
		}
		cliente.setNome(nomeTextField.getText());
		cliente.setBairro(bairroTextField.getText());
		cliente.setCep(cepTextField.getText());
		cliente.setCidade(cidadeTextField.getText());
		cliente.setNumero(numeroTextField.getText());
		cliente.setTelefone(telefoneTextField.getText());
        return cliente;		
	}
	
	protected void pegarDadosClienteFromTabela(Cliente cliente) {
		codigoTextField.setText(String.valueOf(cliente.getId()));
		nomeTextField.setText(cliente.getNome());
		bairroTextField.setText(cliente.getBairro());
		cepTextField.setText(cliente.getCep());
		cidadeTextField.setText(cliente.getCidade());
		numeroTextField.setText(cliente.getNumero());
		telefoneTextField.setText(cliente.getTelefone());
	}


	protected void verificarDigitacao() {
	
		if (nomeTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "O nome do cliente deve ser informado!");
			nomeTextField.requestFocus();
			return;
		} else if (enderecoTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "O endereço do cliente deve ser informado!");
			enderecoTextField.requestFocus();
			return;
		} else if (numeroTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "O número da residencial - apartamento do cliente deve ser informado!");
			numeroTextField.requestFocus();
			return;
		}
		
		
	}


	private void initComponents() {
		setTitle("Cadastro Cliente");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 994, 616);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNome = new JLabel("Nome:");
		
		nomeTextField = new JTextField();
		nomeTextField.setColumns(10);
		
		JLabel lblEndereo = new JLabel("Endereço:");
		
		enderecoTextField = new JTextField();


		enderecoTextField.setColumns(10);
		
		JLabel lblBairro = new JLabel("Bairro:");
		
		bairroTextField = new JTextField();
		bairroTextField.setColumns(10);
		
		JLabel lblCidade = new JLabel("Cidade:");
		
		cidadeTextField = new JTextField();
		cidadeTextField.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		
		telefoneTextField = new JTextField();
		telefoneTextField.setColumns(10);
		
		JLabel lblCep = new JLabel("Cep:");
		
		cepTextField = new JTextField();
		cepTextField.setColumns(10);
		
		JLabel lblNmero = new JLabel("Número:");
		
		numeroTextField = new JTextField();
		numeroTextField.setColumns(10);
		
		btnSalvar = new JButton("Salvar");

		btnExcluir = new JButton("Excluir");
		
		btnCancelar = new JButton("Cancelar");
		
		JLabel lblCdigo = new JLabel("Código:");
		
		codigoTextField = new JTextField();
		codigoTextField.setColumns(10);
		codigoTextField.setEnabled(false);
	
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(90)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblCdigo)
						.addComponent(lblCep)
						.addComponent(lblTelefone)
						.addComponent(lblCidade)
						.addComponent(lblBairro)
						.addComponent(lblNome)
						.addComponent(lblEndereo))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnSalvar)
									.addGap(18)
									.addComponent(btnExcluir)
									.addGap(18)
									.addComponent(btnCancelar))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addComponent(nomeTextField, GroupLayout.PREFERRED_SIZE, 774, GroupLayout.PREFERRED_SIZE)
									.addComponent(telefoneTextField, GroupLayout.PREFERRED_SIZE, 383, GroupLayout.PREFERRED_SIZE)
									.addComponent(cepTextField, GroupLayout.PREFERRED_SIZE, 304, GroupLayout.PREFERRED_SIZE)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
											.addComponent(enderecoTextField, Alignment.LEADING)
											.addComponent(cidadeTextField, Alignment.LEADING)
											.addComponent(bairroTextField, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 522, Short.MAX_VALUE))
										.addGap(33)
										.addComponent(lblNmero)
										.addGap(18)
										.addComponent(numeroTextField)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(codigoTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(41)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCdigo)
						.addComponent(codigoTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(36)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(nomeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNome))
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblEndereo)
						.addComponent(enderecoTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNmero)
						.addComponent(numeroTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblBairro)
						.addComponent(bairroTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCidade)
						.addComponent(cidadeTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblTelefone)
						.addComponent(telefoneTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblCep)
						.addComponent(cepTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(49)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnSalvar)
						.addComponent(btnExcluir)
						.addComponent(btnCancelar))
					.addContainerGap(63, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		
	}
}
